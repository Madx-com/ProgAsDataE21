void main(int n){                                                               
  // ++n;                                                                        
  println;                                                                
  print n;                                                                
  println;                                                                
}                                                                               
   
