//preinc test

void main(int n) {
  int i;
  i = 0;
  while(i < n) {
    ++i;
    print i;
  }
}