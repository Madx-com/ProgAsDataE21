//superif test

void main(int m, int n) {
	(m < n) ? print m : print n;
}