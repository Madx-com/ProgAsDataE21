//predec test

void main(int n) {
  int i;
  i = 10;
  while(i > n) {
    --i;
    print i;
  }
}