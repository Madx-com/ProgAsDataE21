// micro-C example 1

void main(int n) {
  while (n > 0) {
    print n;
    n = n - 1;
  }
  println;
}
