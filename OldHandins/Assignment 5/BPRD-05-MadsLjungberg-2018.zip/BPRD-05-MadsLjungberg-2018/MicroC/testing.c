void main(int n){                                                               
  --n;                                                                    
  print n;                                                               
}                                                                               
