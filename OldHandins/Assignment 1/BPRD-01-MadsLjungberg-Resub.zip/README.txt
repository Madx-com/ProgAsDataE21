To find solutions easier search for the given excercise number like this (* 2.1 *) or (* 1.1 - (i) *)
then it should find the part relating to the given task.

or atleast in the vicinity of the tag.