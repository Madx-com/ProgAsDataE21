To find solutions easier search for the given excercise number like this (* 2.1 *) or (* 1.1 - (i) *)
then it should find the part relating to the given task.

or atleast in the vicinity of the tag.


You can run this by getting the FsLexYacc.Runtime.dll and place it in the folder then check if the driveHandin.bat has the correct path.

I'm having some compile errors in Intcomp that I couldn't resolve. in driveHandin.bat remove the Intcomp1.fs to run the Intro2.fs without errors.