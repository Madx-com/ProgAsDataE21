module Dryrun
	
	open System;;
	open Parse;;
	
	printf("2");;
	let ex = fromString "1 + 2*3";;
	printf("2");;
	let ex1 = fromString "1-2-3";;
	printf("2");;
	let ex2 = fromString "1 + -2";;
	printf("2");;
	//let ex3 = fromString "x++";;
	printf("2");;
	//let ex4 = fromString "1 + 1.2";;
	printf("2");;
	//let ex5 = fromString "1 + ";;
	printf("2");;
	let ex6 = fromString "let z = (17) in z + 2*3end";;
	printf("2");;
	//let ex7 = fromString "let z = 17) in z + 2*3end";;
	printf("2");;
	//let ex8 = fromString "let in = (17) in z + 2*3end";;
	printf("2");;
	let ex9 = fromString "1 + let x=5 in let y=7+x in y+y end + x end";;

	ex;;