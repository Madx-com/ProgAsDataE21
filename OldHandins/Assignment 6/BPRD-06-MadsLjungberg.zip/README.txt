Exercise 6.1 is in the RegEx directory.
Exercise 6.2 is defined in the HigherFun.fs file in Fun directory.
Exercise 6.3 is in the Exercise 6.3 directory.